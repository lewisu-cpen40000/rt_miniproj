#include <wiringPi.h>
void initalizeSegments();
void initalizeKeypad();
void writeNum(int number);
void mPlex();
void shutOffAll();
int readKeyPress();
int decodeKeyPress();
void resetColumns();

//this int array will hold the pins that need
//to be turned on to correctly display the digit
int num_array[10][7] = {  { 1,1,1,1,1,1,0 },    // 0
                          { 0,1,1,0,0,0,0 },    // 1
                          { 1,1,0,1,1,0,1 },    // 2
                          { 1,1,1,1,0,0,1 },    // 3
                          { 0,1,1,0,0,1,1 },    // 4
                          { 1,0,1,1,0,1,1 },    // 5
                          { 1,0,1,1,1,1,1 },    // 6
                          { 1,1,1,0,0,0,0 },    // 7
                          { 1,1,1,1,1,1,1 },    // 8
                          { 1,1,1,0,0,1,1 }};   // 9
//This array holds the current number to be displayed
int number[4] = {0,0,0,0};	

			
int main (void)
{
 	wiringPiSetup () ;
 	initalizeSegments();
	initalizeKeypad();
	int rawKeyPressed;
	int keyPressed;
	int currentDig = 0;
	for(;;){
		rawKeyPressed = readKeyPress();
		if(rawKeyPressed > 0){
			keyPressed = decodeKeyPress(rawKeyPressed);
			number[currentDig] = keyPressed;
			if(currentDig == 3){
				currentDig = 0;
			}else{
				currentDig++;
			}
		}
		mPlex();
	}
  return 0 ;
}

void initalizeSegments(){
	//pins 0-6 will be used for a-g on the 7-seg display
	int i;
	for(i = 0; i < 7; i++){
		pinMode(i, OUTPUT);
	}
	
	//pins 7-10 will be used to control the transistors for each digitalWrite
	for(i = 7; i <11; i++){
		pinMode(i, OUTPUT);
	}
}

void initalizeKeypad(){
	int i;
	//pins 21, 22, 24, and 24 will be used for the columns
	for(i = 21; i<25; i++){
		pinMode(i, OUTPUT);
	//Pins 26,27,28, and 29 will be used for the rows.
	}
	for(i = 26; i < 30; i++){
		pinMode(i, INPUT);
	}
}

//This function will set one column low and read for a corresponding
//low on a row.
int readKeyPress(){
	int i;
	int k;
	for(i = 21; i <25; i++){
		resetColumns();						//reset all columns to high
		digitalWrite(i, 0);					//set one column to low
		delay(2);							//small delay
		for(k = 26; k< 30; k++){
			if(digitalRead(k) == 0){		// If a key press was detected
				delay(30);			 		// delay for a short time
				if(digitalRead(k) == 0){ 	// Read pin again
					delay(20);
					return i * k;
					
				}
			}
		}
	}
	return -1;								//return -1 if no key was pressed
}

int decodeKeyPress(int num){
	switch (num){
		case 546: 
			return 1;
		case 567:
			return 4;
		case 588:
			return 7;
		case 609:
			return 7;
		case 572:
			return 2;
		case 594:
			return 5;
		case 616:
			return 8;
		case 638:
			return 0;
		case 598:
			return 3;
		case 621:
			return 6;
		case 644:
			return 9;
		case 667:
			return 9;
		default:
			return -1;
	}
}
//This function will set all columns back to high.
void resetColumns(){
	int i;
	for(i = 21; i < 25; i++){
		digitalWrite(i, 1);
	}
}

// this function writes values to the seven segment pins  
void writeNum(int number) 
{
	int j;
  	for (j=0; j < 7; j++) {
   	digitalWrite(j, num_array[number][j]);
  	}
}

//This function will shut off all transistors which control the digits.
void shutOffAll(){
	int i;
	for(i = 7; i < 11; i++){
		digitalWrite(i, 0);
	}
}

//This function turns on one digit at a time and writes the proper number
//to that digit.
void mPlex(){
	int k;
	for(k = 7; k < 11; k++){
		shutOffAll();
		digitalWrite(k, 1);
		writeNum(number[k-7]);
		delay(1);
	}
}
