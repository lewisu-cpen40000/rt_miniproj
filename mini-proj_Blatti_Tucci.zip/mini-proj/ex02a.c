#include <stdio.h>
#include <signal.h>
#include <unistd.h>

#include <alchemy/task.h>
#include <alchemy/timer.h>
#include <alchemy/sem.h>

RT_TASK hello_task;
RT_TASK taskDemo;
RT_TASK task1;
RT_TASK task2;
RT_TASK task3;
RT_TASK task4;
RT_TASK task5;

void demo(void *arg) {
    RT_TASK_INFO curtaskinfo;
    rt_task_inquire(NULL,&curtaskinfo);
	int num = * (int *)arg;
    rt_printf("Task name: %s \n", curtaskinfo.name);
	rt_printf("Task number: %d \n", num);
}

void taskOne(void *arg){
	demo(arg);
}
void taskTwo(void *arg){
	demo(arg);
}
void taskThree(void *arg){
	demo(arg);
}
void taskFour(void *arg){
	demo(arg);
}
void taskFive(void *arg){
	demo(arg);
}

int main(int argc, char* argv[])
{
       char str[10] ;
	  int index1 = 1;
	   int index2 = 2;
	   int index3 = 3;
	   int index4 = 4;
	   int index5 = 5;
	   
	   int *ip = &index1;

       printf("start task\n");
       sprintf(str,"hello");
         
       rt_task_create(&task1, "task1", 0, 1, 0);
	   rt_task_create(&task2, "task2", 0, 1, 0);
	   rt_task_create(&task3, "task3", 0, 1, 0);
	   rt_task_create(&task4, "task4", 0, 1, 0);
	   rt_task_create(&task5, "task5", 0, 1, 0);

	   rt_task_start(&task1, &taskOne, &index1);
	   rt_task_start(&task2, &taskTwo, &index2);
	   rt_task_start(&task3, &taskThree, &index3);
	   rt_task_start(&task4, &taskFour, &index4);
	   rt_task_start(&task5, &taskFive, &index5);
}
